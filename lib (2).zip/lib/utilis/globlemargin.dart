import 'package:flutter/material.dart';

class GlobleglobleMargin {
  static final globleMargin =  EdgeInsets.only(top:16.0, left: 10, right: 10);
    static final Margin10H =  EdgeInsets.only( left: 10, right: 10);
     static final Margin10V =  EdgeInsets.only( top: 10, bottom: 10);
      static final Margin10R =  EdgeInsets.only( right: 10);
       static final Margin10L =  EdgeInsets.only( left: 10);
}