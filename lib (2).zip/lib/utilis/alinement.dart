import 'package:flutter/material.dart';

const AlignmentCenterCross = CrossAxisAlignment.center;
const AlignmentStartCross = CrossAxisAlignment.start;
const AlignmentEndCross = CrossAxisAlignment.end;

const AlignmentCenterMain = MainAxisAlignment.center;
const AlignmenStartMain = MainAxisAlignment.start;

const AlignmenEndMain = MainAxisAlignment.end;
