import 'package:flutter/material.dart';

var size10w = const SizedBox(
  width: 10,
);
var size10h =const SizedBox(
  height: 10,
);

var size20w = const SizedBox(
  width: 20,
);
var size20h = const SizedBox(
  height: 20,
);
