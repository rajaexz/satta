import 'dart:convert';

import 'package:winner11/screen/component/darkmode.dart';
import 'package:winner11/screen/component/shimmer.dart';
import 'package:winner11/screen/header/appbar.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:winner11/screen/tap3/blog.dart';
import 'package:winner11/service/authapi.dart';
import 'package:winner11/utilis/AllColor.dart';
import 'package:winner11/utilis/borderbox.dart';
import 'package:winner11/utilis/boxSpace.dart';

import 'package:winner11/utilis/globlemargin.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MyFullBlog extends StatefulWidget {
  const MyFullBlog({super.key});

  @override
  State<MyFullBlog> createState() => _MyFullBlogState();
}
class _MyFullBlogState extends State<MyFullBlog> {
  final ApiService apiService = ApiService();
  List<Map<String, dynamic>> tnews = [];
  final ThemeController themeController = Get.put(ThemeController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: "ALL News"),
      body: 
      
      Container(
        margin: GlobleglobleMargin.globleMargin,
        child: FutureBuilder(
          future: apiService.userallGet(
            uri: "http://sky11.news/wp-json/wp/v2/posts?per_page=15",
          ),
          builder: (context, snapshot) {
            try {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: summer2);
              } else if (snapshot.hasError) {
                print("Error: ${snapshot.error}");
                return Text("Error: ${snapshot.error}");
              } else {
                List<dynamic> newsTrending =
                    (snapshot.data as Map<String, dynamic>)['data'];

                Future<void> fetchSingleData(int index) async {
                  var singleData = await apiService.userallGet(
                      uri: newsTrending[index]['_links']["wp:featuredmedia"][0]['href']);
                  String title = newsTrending[index]['title']['rendered'];
                 String content = newsTrending[index]['content']['rendered'];
                  Map<String, dynamic> newsItem = {
                   'title':title,
                   'content':content,
                    'image': singleData['data']['guid']['rendered'].toString()
                  };

                  tnews.add(newsItem);

                  
                }

                return FutureBuilder(
                  future: Future.wait(
                    List.generate(newsTrending.length, (index) => fetchSingleData(index)),
                  ),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return summer2;
                    } else if (snapshot.hasError) {
                      print("Error: ${snapshot.error}");
                      return Text("Error: ${snapshot.error}");
                    } else {
                      return ListView.builder(
                        itemCount: tnews.length,
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onTap: (){
                               Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    NewsLayout(newsData: tnews[index]['content'])),
                          );
                            },
                            child: Container(
                              margin: const EdgeInsets.only(left: 5, right: 10, top: 20),
                              padding: const EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                color: themeController.isLightMode.value ? myColorWhite : myColor,
                                boxShadow: [
                                  themeController.isLightMode.value ? boxshadow2 : boxdark
                                ],
                                border: border,
                                borderRadius: boRadiusAll,
                              ),
                              child: Column(
                                children: [
                              
                                Container(
                                  height: 200,
                                
                              decoration: BoxDecoration(
                                   borderRadius: boRadiusAll,
                                image: DecorationImage(
                                  image: NetworkImage(tnews[index]['image'].toString()),
                                  fit: BoxFit.cover, // adjust as needed
                                ),
                              ),
                            ),
                            size10h,
                                 HtmlWidget(tnews[index]['title'], textStyle:TextStyle(fontSize: 15) ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    }
                  },
                );
              }
            } catch (e) {
              print("Error: $e");
              return Text("Error: $e");
            }
          },
        ),
      ),
    );
  }
}
