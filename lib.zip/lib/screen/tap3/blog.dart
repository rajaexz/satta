import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:winner11/screen/header/appbar.dart';

import 'package:winner11/utilis/globlemargin.dart';

class NewsLayout extends StatelessWidget {
  final  newsData;

  NewsLayout({required this.newsData});

  @override
  Widget build(BuildContext context) {
   

    return Scaffold(
      appBar:CustomAppBar(
        title: 'WINNER11',
      ),
        body: SafeArea(
          child: SingleChildScrollView(
          child: Container(
            margin: GlobleglobleMargin.globleMargin,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                 HtmlWidget(newsData, textStyle:TextStyle(fontSize: 15) )
             ],
            ),
          ),
              ),
        ),
    );
  }
}
