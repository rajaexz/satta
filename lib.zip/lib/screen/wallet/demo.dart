// import 'dart:async';
// import 'dart:convert';
// import 'dart:io';
// import 'dart:typed_data';

// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:webview_flutter/webview_flutter.dart';
// // #docregion platform_imports
// // Import for Android features.
// import 'package:webview_flutter_android/webview_flutter_android.dart';
// // Import for iOS features.
// import 'package:webview_flutter_wkwebview/webview_flutter_wkwebview.dart';
// import 'package:winner11/screen/wallet/addmoney.dart';
// // #enddocregion platform_imports


// const String kLocalExamplePage = '''
// <!DOCTYPE html>
// <html lang="en">
// <head>
// <title>Load file or HTML string example</title>
// </head>
// <body>

// <h1>Local demo page</h1>
// <p>
//   This is an example page used to demonstrate how to load a local file or HTML
//   string using the <a href="https://pub.dev/packages/webview_flutter">Flutter
//   webview</a> plugin.
// </p>

// </body>
// </html>
// ''';


// class WebViewExample extends StatefulWidget {

//   var Amount ;
//    WebViewExample({super.key , this.Amount});

//   @override
//   State<WebViewExample> createState() => _WebViewExampleState();
// }

// class _WebViewExampleState extends State<WebViewExample> {
//   late final WebViewController _controller;


//   @override
//   void initState() {
//     super.initState();

//     // #docregion platform_features
//     late final PlatformWebViewControllerCreationParams params;
//     if (WebViewPlatform.instance is WebKitWebViewPlatform) {
//       params = WebKitWebViewControllerCreationParams(
//         allowsInlineMediaPlayback: true,
//         mediaTypesRequiringUserAction: const <PlaybackMediaTypes>{},
//       );
//     } else {
//       params = const PlatformWebViewControllerCreationParams();
//     }

//     final WebViewController controller =
//         WebViewController.fromPlatformCreationParams(params);
//     // #enddocregion platform_features

//     controller
//       ..setJavaScriptMode(JavaScriptMode.unrestricted)
//       ..setBackgroundColor(const Color(0x00000000))
   
//       ..addJavaScriptChannel(
//         'Toaster',
//         onMessageReceived: (JavaScriptMessage message) {
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(content: Text(message.message)),
//           );
//         },
//       );
//     // #docregion platform_features
//     if (controller.platform is AndroidWebViewController) {
//       AndroidWebViewController.enableDebugging(true);
//       (controller.platform as AndroidWebViewController)
//           .setMediaPlaybackRequiresUserGesture(false);
//     }
//     // #enddocregion platform_features
// tapPayhitApi();
//     _controller = controller;
//   }

//   Future<void> _onLoadHtmlStringExample(kNavigationExamplePage) {
  
//     return _controller.loadRequest(
//       Uri.parse('http://sky11live.com/nodeserver/checkTapPay.php'),
//       method: LoadRequestMethod.post,
//       headers: <String, String>{
//     'amount': '100',
//     'currency': 'IND',
//     'email': 'Rajahalder@gmail.com',
//     'phone': '7011448878',
//     'order_id': valueController.generateOrderId(),
//   },
//       body: Uint8List.fromList('Test Body'.codeUnits),
//     );
  

//   }

//  tapPayhitApi() async {
//   var url = 'http://sky11live.com/nodeserver/checkTapPay.php';
// print("iiii");
//   // Your request data
//   var data = {
//     'amount': '100',
//     'currency': 'IND',
//     'email': 'Rajahalder@gmail.com',
//     'phone': '7011448878',
//     'order_id': valueController.generateOrderId(),
//   };

//   // Make the HTTP POST request
//   var response = await http.post(
//     Uri.parse(url),
//     body: data,
//   );

//   // Handle the response
//   if (response.statusCode == 200) {
// print(response.body);

//   } else {
//     print('Request failed with status: ${response.statusCode}');
//     print('Error message: ${response.body}');
//   }
// }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.green,
//       appBar: AppBar(
//         title: const Text('Flutter WebView example'),
//         // This drop down menu demonstrates that Flutter widgets can be shown over the web view.
//         actions: <Widget>[
      
//         ],
//       ),
//       body: WebViewWidget(controller: _controller, ),
    
//     );
//   }

// }

// enum MenuOptions {
 

//   loadHtmlString,
 
// }
import 'package:html/parser.dart' show parse;
import 'package:html/dom.dart';
import 'package:url_launcher/url_launcher.dart';

Future<void> launchURL(String url) async {
  if (await canLaunchUrl(Uri.parse(url))) {
    await launchUrl(Uri.parse(url));
  } else {
    throw 'Could not launch $url';
  }
}
List<String> findRelevantLinks(String htmlContent) {
  var document = parse(htmlContent);
  List<Element> links = document.querySelectorAll('a');
  List<String> relevantLinks = [];

  for (var link in links) {
    String href = link.attributes['href'] ?? '';
    if (href.contains('gpay://upi/pay?') || href.contains('upi://pay?') || href.contains('phonepe://pay?') || href.contains(' paytmmp://pay?') ) {
      relevantLinks.add(href);
    }
  }
  return relevantLinks;
}
